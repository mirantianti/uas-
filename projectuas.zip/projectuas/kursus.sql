-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Jun 2024 pada 15.34
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kursus`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(2, 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `halaman`
--

CREATE TABLE `halaman` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `kutipan` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `tgl_isi` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `halaman`
--

INSERT INTO `halaman` (`id`, `judul`, `kutipan`, `isi`, `tgl_isi`) VALUES
(15, 'Kursus Online ', 'Mengasah Kemampuan anda', '<p><span style=\"color: rgb(51, 51, 51); font-family: Roboto, sans-serif; font-size: 14px; text-align: justify;\">Kursus online atau belajar online adalah serangkaian pengalaman instruksional dengan menggunakan jaringan digital untuk berinteraksi, belajar dan berdiskusi. Kursus online tidak memerlukan pertemuan tatap muka di lokasi fisik.</span><br></p><p><img src=\"../gambar/e00da03b685a0dd18fb6a08af0923de0.jpg\" style=\"width: 50%;\"><br></p>', '2024-06-27 09:37:27'),
(17, 'About Kursus', 'You Will Need This', '<p><img src=\"../gambar/3988c7f88ebcb58c6ce932b957b6f332.jpg\" style=\"width: 626px; float: left;\" class=\"note-float-left\">Website ini memudahkan anda untuk mendapatkan seorang Guru yang handal dalam bidang sesuai minat anda mau tempuh</p>', '2024-06-24 12:51:24');

-- --------------------------------------------------------

--
-- Struktur dari tabel `info`
--

CREATE TABLE `info` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `tgl_isi` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `info`
--

INSERT INTO `info` (`id`, `judul`, `isi`, `tgl_isi`) VALUES
(1, 'About', 'Kami menyediakan beragam pelatihan yang bisa teman-teman gunakan', '2024-06-27 09:53:43'),
(3, 'Contact', '<p>Nomor : 082134576890</p>', '2024-06-27 09:28:45'),
(4, 'Social', '<p>Instagram : rudiharung253</p>', '2024-06-27 09:54:24');

-- --------------------------------------------------------

--
-- Struktur dari tabel `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `nama_lengkap` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `status` text NOT NULL,
  `token_ganti_password` text NOT NULL,
  `tgl_isi` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `members`
--

INSERT INTO `members` (`id`, `email`, `nama_lengkap`, `password`, `status`, `token_ganti_password`, `tgl_isi`) VALUES
(3, 'paskalisdatul1@gmail.com', 'Profile', 'e10adc3949ba59abbe56e057f20f883e', 'b5b41fac0361d157d9673ecb926af5ae', '0353ab4cbed5beae847a7ff6e220b5cf', '2024-06-28 10:36:55');

-- --------------------------------------------------------

--
-- Struktur dari tabel `partners`
--

CREATE TABLE `partners` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `tgl_isi` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `partners`
--

INSERT INTO `partners` (`id`, `nama`, `foto`, `isi`, `tgl_isi`) VALUES
(1, 'Institut Bisnis Dan Teknologi Indonesia', 'partners_1719476510_Vertical-Logo-1024x1024.png', '<p><span style=\"color: rgba(0, 0, 0, 0.9); font-family: -apple-system, system-ui, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, &quot;Fira Sans&quot;, Ubuntu, Oxygen, &quot;Oxygen Sans&quot;, Cantarell, &quot;Droid Sans&quot;, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Lucida Grande&quot;, Helvetica, Arial, sans-serif; white-space-collapse: preserve;\">INSTIKI pertama kali didirikan tanggal 18 April 2008 dan berada di bawah pengelolaan Yayasan Wahana Widya Wisesa Denpasar. Melalui SK MENDIKNAS RI No. 70/D/O/2008 disetujui untuk menyelenggarakan dua program studi yaitu Sistem Komputer dan Teknik Informatika. Berdasarkan Keputusan BAN-PT No. 952/SK/BAN-PT/Akred/PT/XI/2020, menyatakan bahwa INSTIKI telah mendapatkan akreditasi dengan peringkat “B”  dan masuk Klaster Madya Perguruan Tinggi Berbasis Kinerja Penelitian dari Kemenristek/BRIN.</span><br></p>', '2024-06-27 09:45:18'),
(2, 'Universitas Udayana', 'partners_1719476597_76dc611d6ebaafc66cc0879c71b5db5c.png', '<p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\"><b>Universitas Udayana</b>&nbsp;(disingkat&nbsp;<b>UNUD</b>) adalah sebuah Universitas Negeri yang terletak di&nbsp;<a href=\"https://id.wikipedia.org/wiki/Jimbaran,_Kuta_Selatan,_Badung\" title=\"Jimbaran, Kuta Selatan, Badung\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word;\">Jimbaran</a>,&nbsp;<a href=\"https://id.wikipedia.org/wiki/Kabupaten_Badung\" title=\"Kabupaten Badung\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word;\">Kabupaten Badung</a>,&nbsp;<a href=\"https://id.wikipedia.org/wiki/Bali\" title=\"Bali\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word;\">Bali</a>,&nbsp;<a href=\"https://id.wikipedia.org/wiki/Indonesia\" title=\"Indonesia\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word;\">Indonesia</a>. Universitas Udayana berdiri pada tanggal 29 September 1962.<br></p><p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\">Cikal bakal Universitas Udayana adalah Fakultas Sastra cabang&nbsp;<a href=\"https://id.wikipedia.org/wiki/Universitas_Airlangga\" title=\"Universitas Airlangga\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Universitas Airlangga</a>&nbsp;yang berdiri oleh prakarsa Letnan Kolonel Minggoe dan&nbsp;<a href=\"https://id.wikipedia.org/wiki/Teuku_Daudsjah\" title=\"Teuku Daudsjah\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Teuku Muhammad Daoedsjah</a>&nbsp;selaku pemimpin Yayasan-Yayasan Fakultas Nusa Tenggara. Yayasan ini bekerja sama dengan orang-orang yang memliki keahlian dalam bidang ilmu susastra, seperti&nbsp;<a href=\"https://id.wikipedia.org/wiki/Ida_Bagus_Mantra\" title=\"Ida Bagus Mantra\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Dr. Ida Bagus Mantra</a>,&nbsp;<a href=\"https://id.wikipedia.org/wiki/Roelof_Goris\" title=\"Roelof Goris\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Dr. Roelof Goris</a>, dan I Gusti Ketut Ranuh. Orang-orang ini, selain mempersipakan segala sesuatu yang berkenaan dengan segi fisik, juga bertugas untuk merekrut tenaga-tenaga yang akan dijadikan sebagai pengajar (dosen). Tenaga pengajar yang berhasil direkrut antara lain&nbsp;<a href=\"https://id.wikipedia.org/wiki/Poerbatjaraka\" title=\"Poerbatjaraka\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Prof. Dr. Mpu Raden Mas Ngabehi Poerbatjaraka</a>,&nbsp;<a href=\"https://id.wikipedia.org/w/index.php?title=Swami_Ajarananda&amp;action=edit&amp;redlink=1\" class=\"new\" title=\"Swami Ajarananda (halaman belum tersedia)\" style=\"text-decoration-line: none; color: var(--color-link-red,#d73333); background: none; border-radius: 2px; overflow-wrap: break-word;\">Prof. Dr. Swami Ajarananda</a>,&nbsp;<a href=\"https://id.wikipedia.org/wiki/Ida_Bagus_Mantra\" title=\"Ida Bagus Mantra\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Dr. Ida Bagus Mantra</a>, dan&nbsp;<a href=\"https://id.wikipedia.org/wiki/Roelof_Goris\" title=\"Roelof Goris\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Dr. Roelof Goris</a>.</p><p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\">Fakultas Sastra kemudian diresmikan oleh Presiden Republik Indonesia,&nbsp;<a href=\"https://id.wikipedia.org/wiki/Ir._Soekarno\" class=\"mw-redirect\" title=\"Ir. Soekarno\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Ir. Soekarno</a>&nbsp;dan dibuka oleh&nbsp;<b>Menteri Pendidikan, Pengajaran, dan Kebudayaan</b>,&nbsp;<a href=\"https://id.wikipedia.org/wiki/Prijono\" title=\"Prijono\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Prof. Dr. Priyono</a>&nbsp;pada tanggal 29 September 1958 sebagaimana tertulis pada prasasti di Fakultas Sastra, Jalan Nias,&nbsp;<a href=\"https://id.wikipedia.org/wiki/Denpasar\" class=\"mw-redirect\" title=\"Denpasar\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Denpasar</a>. Universitas Udayana secara sah berdiri pada tanggal 17 Agustus 1962 dan merupakan perguruan tinggi negeri tertua di Provinsi Bali.</p><p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\">Fakultas Sastra inilah yang merupakan&nbsp;<a href=\"https://id.wikipedia.org/wiki/Embrio\" title=\"Embrio\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">embrio</a>&nbsp;dari berdirinya Universitas Udayana. Berdasarkan Surat Keputusan Menteri PTIP No.104/1962, tanggal 9 Agustus 1962, Universitas Udayana secara sah berdiri sejak tanggal 17 Agustus 1962. Akan tetapi, karena hari lahir Universitas Udayana jatuh bersamaan dengan hari Kemerdekaan Republik Indonesia, perayaan hari ulang tahun Universitas Udayana dialihkan menjadi tanggal&nbsp;<a href=\"https://id.wikipedia.org/wiki/29_September\" title=\"29 September\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">29 September</a>&nbsp;dengan mengambil tanggal peresmian fakultas sastra yang telah berdiri sejak tahun 1958.</p>', '2024-06-27 09:47:28'),
(3, 'Universitas Pendidikan Nasional', 'partners_1719476659_UNDIKNAS-COLOR-1024x1024.png', '<p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\"><b>Universitas Pendidikan Nasional</b>,</p><p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\">disingkat&nbsp;<b>Undiknas</b>&nbsp;adalah sebuah&nbsp;<a href=\"https://id.wikipedia.org/wiki/Perguruan_tinggi\" title=\"Perguruan tinggi\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">perguruan tinggi</a>&nbsp;swasta di&nbsp;<a href=\"https://id.wikipedia.org/wiki/Denpasar\" class=\"mw-redirect\" title=\"Denpasar\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Denpasar</a>,&nbsp;<a href=\"https://id.wikipedia.org/wiki/Bali\" title=\"Bali\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Bali</a>. Perguruan tinggi ini didirikan oleh Prof. Dr. IGN Gorda, M.S. dan Drs. Ketut Sambereg, M.M. Sebelum berubah nama menjadi Universitas Pendidikan Nasional, dulu bernama AKABA (Akademi Keuangan dan Perbankan) yang berdiri pada tahun&nbsp;<a href=\"https://id.wikipedia.org/wiki/17_Februari\" title=\"17 Februari\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">17 Februari</a>&nbsp;<a href=\"https://id.wikipedia.org/wiki/1969\" title=\"1969\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">1969</a>&nbsp;oleh Yayasan Pendidikan Kejuruan Nasional (YPKN). Dalam rangka memperluas cakupan program pendidikan yang diselenggarakan oleh AKABA, pegembangan kelembagaan kembali dilakukan pada tahun 1980 dengan perubahan AKABA menjadi Sekolah Tinggi Ilmu Keuangan (STIK) Denpasar. Selanjutnya, guna menjawab tantangan dunia pendidikan di tingkat perguruan tinggi yang semakin dinamis pada tahun 1980-an, serta untuk mengakomodasi visi dan misi STIK Denpasar yang terus berkembang, pada tahun 1984 STIK Denpasar meningkatkan status kelembagaannya menjadi universitas, yaitu&nbsp;<a rel=\"nofollow\" class=\"external text\" href=\"https://undiknas.ac.id/\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: url(&quot;/w/skins/Vector/resources/skins.vector.styles/images/link-external-small-ltr-progressive.svg?fb64d&quot;) right center / 0.857em no-repeat; border-radius: 2px; overflow-wrap: break-word; padding-right: 1em;\">Universitas Pendidikan Nasional (Undiknas)</a>, sebuah lembaga pendidikan tinggi yang beroperasi hingga saat ini.</p>', '2024-06-27 09:48:25'),
(4, 'Universitas Warmadewa', 'partners_1719476708_UNWAR.jpg', '<p><b style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">Universitas Warmadewa</b><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">&nbsp;atau biasa disingkat&nbsp;</span><b style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">Unwar</b><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">&nbsp;merupakan salah satu perguruan tinggi di&nbsp;</span><a href=\"https://id.wikipedia.org/wiki/Denpasar\" class=\"mw-redirect\" title=\"Denpasar\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">Denpasar</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">,&nbsp;</span><a href=\"https://id.wikipedia.org/wiki/Bali\" title=\"Bali\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">Bali</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">. Berada di lingkungan&nbsp;</span><a href=\"https://id.wikipedia.org/wiki/Kopertis\" class=\"mw-redirect\" title=\"Kopertis\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">Kopertis</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">&nbsp;Wilayah VIII di bawah naungan Yayasan Korpri Bali. Nama universitas diusulkan oleh Gubernur Bali saat itu,&nbsp;</span><a href=\"https://id.wikipedia.org/wiki/Ida_Bagus_Mantra\" title=\"Ida Bagus Mantra\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">Prof. Dr. Ida Bagus Mantra</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">&nbsp;(alm) untuk menghormati dan mengenang seorang raja Bali sebelum pemerintahan&nbsp;</span><a href=\"https://id.wikipedia.org/wiki/Majapahit\" title=\"Majapahit\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">Majapahit</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">,&nbsp;</span><a href=\"https://id.wikipedia.org/wiki/Sri_Kesari_Warmadewa\" title=\"Sri Kesari Warmadewa\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">Sri Kesari Warmadewa</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">.</span></p><p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\">Pada 12 November 1983, dalam acara Rapat Kerja Daerah Korpri Bali di Kertasabha Denpasar, Ketua Unit Korpri Universitas Udayana Prof. Drs. Putu Kuna Winaya mengusulkan pendirian Universitas Korpri, dengan prinsip dasar \"biaya pendidikan terjangkau dan mutu terjamin\" yang dikembangkan menjadi \"bermutu, berintegritas dan berwawasan lingkungan\". Usulan pendirian Universitas ini dimaksudkan sebagai upaya untuk menampung aspirasi masyarakat yang belum terakomodasi di Perguruan Tinggi Negeri. Setelah mendapat ijin Korpri Pusat, Ketua Pengurus Korpri Bali (Drs. Sembah Subhakti) dan Ketua Korpri Unit Universitas Udayana (Prof. Drs. Putu Kuna Winaya) sepakat untuk membentuk Universitas Korpri.</p><p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\">Pada bulan Juni 1984, dilakukan penyusunan proposal pendirian Universitas Korpri dengan melibatkan unsur Korpri Universitas Udayana dan Korpri Pemerintah Daerah, sekaligus menetapkan Badan Pendiri yang terdiri dari Drs. Sembah Subhakti, Prof Drs. Putu Kuna Winaya, I Ketut Widjana, SH, dan I Wayan Waya, SH.</p><p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\">Pada tanggal 17 Juli 1984, Universitas Warmadewa resmi didirikan dan kepengurusan yayasan ditetapkan susunannya pada Rapat Korpri Bali tanggal 30 Juli 1984. Setelah kelengkapan Badan-Badan Yayasan terbentuk, selanjutnya dilaporkan kepada Kopertis Wilayah VIII, bahwa Universitas Korpri telah berdiri dengan nama Universitas Warmadewa. Nama Universitas Warmadewa diberikan oleh Gubernur Bali pada waktu itu,&nbsp;<a href=\"https://id.wikipedia.org/wiki/Ida_Bagus_Mantra\" title=\"Ida Bagus Mantra\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Prof. Dr. Ida Bagus Mantra</a>, sebagai bentuk apresiasi terhadap raja Bali zaman sebelum Majapahit dari Dinasti Warmadewa. Pada tanggal 15 Agustus 1984, Prof. dr. I Gusti Agung Gde Puthra ditetapkan sebagai Rektor Pertama Universitas Warmadewa. Perkuliahan perdana dilakukan di halaman Kampus Unud pada tanggal 17 September 1984 yang sampai sekarang diperingati sebagai hari lahirnya Universitas Warmadewa.</p><p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\">Sesuai SK Yayasan Kesejahteraan Korpri Propinsi Bali No. 05/ Yas.Korp/VII/84, Universitas Warmadewa terdiri atas 6 (enam) fakultas dan 1 (satu) pendidikan non-gelar, antara lain;</p><ol style=\"margin: -0.5em 0px 0px 3.2em; padding: 0px; list-style-image: none; color: rgb(32, 33, 34); font-family: sans-serif;\"><li style=\"margin-bottom: 0.1em;\">Fakultas Ekonomi</li><li style=\"margin-bottom: 0.1em;\">Fakultas Hukum</li><li style=\"margin-bottom: 0.1em;\">Fakultas Sastra</li><li style=\"margin-bottom: 0.1em;\">Fakultas&nbsp;<a href=\"https://id.wikipedia.org/wiki/Ilmu_sosial\" title=\"Ilmu sosial\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Ilmu Sosial</a>&nbsp;dan Ilmu Politik</li><li style=\"margin-bottom: 0.1em;\">Fakultas Pertanian</li><li style=\"margin-bottom: 0.1em;\">Fakultas Teknik</li><li style=\"margin-bottom: 0.1em;\">Fakultas Keguruan dan Ilmu Pendidikan.</li></ol><p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\">Sejak 25 November 1986, sesuai dengan SK Menteri Pendidikan dan Kebudayaan RI No. 0825/0/1986, Unwar telah ditetapkan dalam Status Terdaftar bagi ke-6 (enam) fakultas dan terakhir berdasarkan SK Mendikbud RI No. 455/0/1991 tanggal 8 Agustus 1991, No. 0641/0/1991 tanggal 13 Desember 1992 serta SK Dirjen Dikti No. 81/Kep/1992 tanggal 2 April 1992 seluruh Fakultas/ Jurusan/ Program Studi di lingkungan Universitas Warmadewa telah berstatus&nbsp;<i>\"Diakui\"</i>.</p><p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\">Saat ini, Universitas Warmadewa dengan motto: \"Guna Widya Sewaka Nagara\" memiliki 14 Progam Studi Sarjana (S1) dan 3 Program Pascasarjana (S2) yaitu:&nbsp;<a href=\"https://id.wikipedia.org/wiki/Magister_Manajemen\" title=\"Magister Manajemen\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Magister Manajemen</a>, Magister Ilmu Hukum, dan Magister Linguistik yang telah memiliki Ijin Operasional. Sedangkan Program Studi S1 Psikologi, S2 Magister Ilmu Pemerintahan (MIP), dan Magister&nbsp;<a href=\"https://id.wikipedia.org/wiki/Administrasi_publik\" title=\"Administrasi publik\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Administrasi Publik</a>&nbsp;(MAP) sedang dalam proses pengusulan ke Dikti Kemendikbud RI</p><p><br></p>', '2024-06-27 09:51:35');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tutors`
--

CREATE TABLE `tutors` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `tgl_isi` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tutors`
--

INSERT INTO `tutors` (`id`, `nama`, `foto`, `isi`, `tgl_isi`) VALUES
(2, 'Budi Rahardjo', 'tutors_1719239748_tutors_1617208710_Budi Rahardjo.jpg', '<p><b style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">Budi Rahardjo<span style=\"font-size: 12.8px; text-wrap: nowrap;\">&nbsp;</span></b><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">berprofesi sebagai dosen, praktisi teknologi informasi dan ahli keamanan informasi. Technopreneur, penulis, peneliti, pembicara, konsultan information security, blogger, rocker, itulah beberapa profesi yang dilakoni oleh Ir. Budi Rahardjo, MSc, PhD. Dengan gayanya yang khas,</span><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">&nbsp;ini turut memberikan kontribusi untuk perkembangan dan kemajuan teknologi informasi di Indonesia.</span><br></p>', '2024-06-27 09:39:28'),
(5, 'Ricky Elson', 'tutors_1719240450_tutors_1617402687_Ricky Elson.jpg', '<p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\"><b>Ricky Elson</b>&nbsp;(lahir 11 Juni 1980) adalah seorang teknokrat&nbsp;<a href=\"https://id.wikipedia.org/wiki/Indonesia\" title=\"Indonesia\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Indonesia</a>&nbsp;yang ahli dalam&nbsp;<a href=\"https://id.wikipedia.org/wiki/Teknologi\" title=\"Teknologi\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">teknologi</a>&nbsp;<a href=\"https://id.wikipedia.org/wiki/Motor\" title=\"Motor\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">motor</a>&nbsp;penggerak listrik. Ia yang merancang bangun mobil listrik&nbsp;<i><a href=\"https://id.wikipedia.org/wiki/Selo_(mobil_listrik)\" title=\"Selo (mobil listrik)\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Selo</a></i>&nbsp;bersama&nbsp;<a href=\"https://id.wikipedia.org/w/index.php?title=Danet_Suryatama&amp;action=edit&amp;redlink=1\" class=\"new\" title=\"Danet Suryatama (halaman belum tersedia)\" style=\"text-decoration-line: none; color: var(--color-link-red,#d73333); background: none; border-radius: 2px; overflow-wrap: break-word;\">Danet Suryatama</a>&nbsp;yang merancang bangun&nbsp;<i><a href=\"https://id.wikipedia.org/wiki/Tucuxi\" title=\"Tucuxi\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Tucuxi</a></i>&nbsp;dianggap sebagai pelopor mobil listrik nasional.</p><p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\">Ricky menempuh pendidikan tinggi teknologinya di&nbsp;<a href=\"https://id.wikipedia.org/wiki/Jepang\" title=\"Jepang\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Jepang</a>, kemudian bekerja di sebuah perusahaan di negeri sakura itu. Selama 14 tahun di sana, Ricky telah menemukan belasan teknologi motor penggerak listrik yang sudah di<a href=\"https://id.wikipedia.org/wiki/Paten\" title=\"Paten\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">patenkan</a>&nbsp;di Jepang.</p>', '2024-06-27 09:40:31'),
(8, 'Romi Satrio Wahono', 'tutors_1719240622_tutors_1617209015_Romi Satrio Wahono (1).jpg', '<p><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">&nbsp;</span><b style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">Romi Satria Wahono</b><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">,&nbsp;</span><a href=\"https://en.wikipedia.org/wiki/Bachelor_of_Engineering\" class=\"extiw\" title=\"en:Bachelor of Engineering\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">B.Eng.</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">,&nbsp;</span><a href=\"https://en.wikipedia.org/wiki/Master_of_Engineering\" class=\"extiw\" title=\"en:Master of Engineering\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">M.Eng.</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">,&nbsp;</span><a href=\"https://en.wikipedia.org/wiki/Doctor_of_Philosophy\" class=\"extiw\" title=\"en:Doctor of Philosophy\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">Ph.D.</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">&nbsp;(</span><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">2 Oktober 1974)</span><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">&nbsp;merupakan Ilmuwan, ahli dan pakar di bidang pengembangan&nbsp;</span><a href=\"https://id.wikipedia.org/wiki/Perangkat_lunak\" title=\"Perangkat lunak\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">perangkat lunak</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">, enterprise architecture, dan machine learning. Ia merupakan pendiri sekaligus&nbsp;</span><a href=\"https://id.wikipedia.org/wiki/CEO\" class=\"mw-redirect\" title=\"CEO\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">CEO</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">&nbsp;dari PT Brainmatics Indonesia Cendekia dan PT IlmuKomputer.com Braindevs Sistema.</span><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">&nbsp;Selain itu, ia merupakan pencetus dari \"</span><i style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">Framework Multidimensi dan Terintegrasi untuk Transformasi Digital</i><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">\" (</span><a href=\"https://id.wikipedia.org/wiki/Bahasa_Inggris\" title=\"Bahasa Inggris\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">bahasa Inggris</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">:&nbsp;</span><span lang=\"en\" style=\"color: rgb(32, 33, 34); font-family: sans-serif;\"><i>integrated multidimensional (id) Framework for Digital Transformation</i></span><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">) yang saat ini telah diterapkan di sejumlah lembaga&nbsp;</span><a href=\"https://id.wikipedia.org/wiki/Kementerian\" title=\"Kementerian\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">kementerian</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">, badan usaha&nbsp;</span><a href=\"https://id.wikipedia.org/wiki/BUMN\" class=\"mw-redirect\" title=\"BUMN\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">negara</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">&nbsp;dan&nbsp;</span><a href=\"https://id.wikipedia.org/wiki/BUMS\" class=\"mw-redirect\" title=\"BUMS\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">swasta</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">. Dikatakan bahwa framework ini \"membantu dan mempercepat proses\" [</span><i style=\"color: rgb(32, 33, 34); font-family: sans-serif;\"><a href=\"https://id.wikipedia.org/wiki/Sic\" title=\"Sic\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">sic</a></i><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">] transformasi digital di lembaga&nbsp;</span><a href=\"https://id.wikipedia.org/wiki/Kementerian\" title=\"Kementerian\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">kementerian</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">, badan usaha&nbsp;</span><a href=\"https://id.wikipedia.org/wiki/BUMN\" class=\"mw-redirect\" title=\"BUMN\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">negara</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">&nbsp;dan&nbsp;</span><a href=\"https://id.wikipedia.org/wiki/BUMS\" class=\"mw-redirect\" title=\"BUMS\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; border-radius: 2px; overflow-wrap: break-word; font-family: sans-serif;\">swasta</a><span style=\"color: rgb(32, 33, 34); font-family: sans-serif;\">.</span><br></p>', '2024-06-27 09:43:12'),
(9, 'Onno W. Purbo', 'tutors_1719240564_tutors_1617209038_onno w purbo.jpg', '<p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\"><a href=\"https://id.wikipedia.org/wiki/Profesor\" title=\"Profesor\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Prof.</a>&nbsp;<a href=\"https://id.wikipedia.org/wiki/Insinyur\" class=\"mw-redirect\" title=\"Insinyur\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Ir.</a>&nbsp;<b>Onno Widodo Purbo</b>,&nbsp;<a href=\"https://en.wikipedia.org/wiki/master_of_engineering\" class=\"extiw\" title=\"en:master of engineering\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">M.Eng.</a>,&nbsp;<a href=\"https://en.wikipedia.org/wiki/Doctor_of_Philosophy\" class=\"extiw\" title=\"en:Doctor of Philosophy\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Ph.D.</a>&nbsp;(lahir 17 Agustus 1962) adalah seorang Tokoh besar, Ilmuwan dan pakar di bidang&nbsp;<a href=\"https://id.wikipedia.org/wiki/Teknologi_informasi\" title=\"Teknologi informasi\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">teknologi informasi</a>&nbsp;asal&nbsp;<a href=\"https://id.wikipedia.org/wiki/Indonesia\" title=\"Indonesia\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Indonesia</a>.<sup id=\"cite_ref-kompas_1-0\" class=\"reference\" style=\"line-height: 1; unicode-bidi: isolate; text-wrap: nowrap; font-size: 12.8px;\"><a href=\"https://id.wikipedia.org/wiki/Onno_W._Purbo#cite_note-kompas-1\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">[1]</a></sup>&nbsp;Selain pakar, Onno juga dikenal sebagai penulis, pendidik, dan pembicara seminar.<sup id=\"cite_ref-kompas_1-1\" class=\"reference\" style=\"line-height: 1; unicode-bidi: isolate; text-wrap: nowrap; font-size: 12.8px;\"><a href=\"https://id.wikipedia.org/wiki/Onno_W._Purbo#cite_note-kompas-1\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">[1]</a></sup>&nbsp;Sebagai aktivis Onno dikenal dalam upayanya memperjuangkan&nbsp;<a href=\"https://id.wikipedia.org/wiki/Linux\" title=\"Linux\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Linux</a>. Karya inovatifnya diantaranya adalah&nbsp;<a href=\"https://id.wikipedia.org/wiki/Wajanbolic_e-goen\" title=\"Wajanbolic e-goen\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Wajanbolic</a>, sebagai upaya koneksi internet murah tanpa kabel dan&nbsp;<a href=\"https://id.wikipedia.org/w/index.php?title=RT/RW-Net&amp;action=edit&amp;redlink=1\" class=\"new\" title=\"RT/RW-Net (halaman belum tersedia)\" style=\"text-decoration-line: none; color: var(--color-link-red,#d73333); background: none; border-radius: 2px; overflow-wrap: break-word;\">RT/RW-Net</a>&nbsp;sebagai jaringan komputer swadaya masyarakat untuk menyebarkan internet murah, serta penerapan&nbsp;<a href=\"https://id.wikipedia.org/w/index.php?title=Open_BTS&amp;action=edit&amp;redlink=1\" class=\"new\" title=\"Open BTS (halaman belum tersedia)\" style=\"text-decoration-line: none; color: var(--color-link-red,#d73333); background: none; border-radius: 2px; overflow-wrap: break-word;\">Open BTS</a><sup id=\"cite_ref-kompas_1-2\" class=\"reference\" style=\"line-height: 1; unicode-bidi: isolate; text-wrap: nowrap; font-size: 12.8px;\"><a href=\"https://id.wikipedia.org/wiki/Onno_W._Purbo#cite_note-kompas-1\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">[1]</a></sup><sup id=\"cite_ref-2\" class=\"reference\" style=\"line-height: 1; unicode-bidi: isolate; text-wrap: nowrap; font-size: 12.8px;\"><a href=\"https://id.wikipedia.org/wiki/Onno_W._Purbo#cite_note-2\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">[2]</a></sup></p><p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\">Ia memulai pendidikan akademis di&nbsp;<a href=\"https://id.wikipedia.org/wiki/ITB\" class=\"mw-redirect\" title=\"ITB\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">ITB</a>&nbsp;pada jurusan Teknik Elektro pada tahun 1981 dan lulus dengan predikat wisudawan terbaik, kemudian melanjutkan studi ke&nbsp;<a href=\"https://id.wikipedia.org/wiki/Kanada\" title=\"Kanada\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Kanada</a>&nbsp;dengan beasiswa dari&nbsp;<a href=\"https://id.wikipedia.org/w/index.php?title=PAUME&amp;action=edit&amp;redlink=1\" class=\"new\" title=\"PAUME (halaman belum tersedia)\" style=\"text-decoration-line: none; color: var(--color-link-red,#d73333); background: none; border-radius: 2px; overflow-wrap: break-word;\">PAUME</a>.</p><p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\">Ia juga aktif menulis dalam bidang teknologi informasi media, seminar, konferensi nasional maupun internasional dan percaya filosofi&nbsp;<i>copyleft</i>&nbsp;(sumber terbuka), banyak tulisannya dipublikasi secara gratis di internet.&nbsp;Sebagai pakar teknologi Onno hanya menggunakan netbook dan telepon seluler Android merek lokal.</p><p style=\"margin: 0.5em 0px 1em; color: rgb(32, 33, 34); font-family: sans-serif;\">Pada bulan November 2020, ia menerima penghargaan&nbsp;<a href=\"https://id.wikipedia.org/wiki/Penghargaan_Jonathan_B._Postel\" title=\"Penghargaan Jonathan B. Postel\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Postel Service Award</a>&nbsp;dari&nbsp;<a href=\"https://id.wikipedia.org/wiki/ISOC\" title=\"ISOC\" style=\"text-decoration-line: none; color: var(--color-progressive,#36c); background: none; border-radius: 2px; overflow-wrap: break-word;\">Internet Society</a>. Postel Service Award diberikan kepada Onno karena telah memberikan kontribusi luar biasa bagi perkembangan teknologi Internet di Indonesia.</p>', '2024-06-27 09:42:01');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `halaman`
--
ALTER TABLE `halaman`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tutors`
--
ALTER TABLE `tutors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `halaman`
--
ALTER TABLE `halaman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `info`
--
ALTER TABLE `info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `partners`
--
ALTER TABLE `partners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tutors`
--
ALTER TABLE `tutors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php include("inc_header.php")?>
<style>
    table {
    width: 600px;
}

@media screen and (max-width: 700px){
    table {
        width: 90%;
    }
}
table td {
    padding: 5px;
}
td.label { width: 40%;}
.input {
    border: 1px solid #CCCCCC;
    background-color: #dfdfdf;
    border-radius: 5px;
    padding: 10px;
    width: 100%;
}
input.tbl-biru {
    border: none;
    background-color: #3f72af;
    border-radius: 20px;
    margin-top: 20px;
    padding: 15px 20px 15px 20px;
    color:#FFFFFF;
    cursor:pointer;
    font-weight: bold;
}
input.tbl-biru:hover {
    background-color: #fc5185;
    text-decoration: none;
}
.error {
    padding: 20px;
    background-color: #f44336;
    color: #FFFFFF;
    margin-bottom: 15px;
}

.sukses {
    padding: 20px;
    background-color: #2196F3;
    color: #FFFFFF;
    margin-bottom: 15px;
}

.error ul { margin-left: 10px; }
</style>
<h3>Lupa Password</h3>
<?php 
if(isset($_SESSION['members_email']) != ''){
    header("location:index.php");
    exit();
}

$err    = "";
$sukses = "";
$email  = "";

if(isset($_POST['submit'])){
    $email  = $_POST['email'];
    if($email == ''){
        $err = "Silakan masukkan email";
    }else{
        $sql1 = "select * from members where email = '$email'";
        $q1   = mysqli_query($koneksi,$sql1);
        $n1   = mysqli_num_rows($q1);

        if($n1 < 1){
            $err = "Email: <b>$email</b> tidak ditemukan";
        }
    }

    if(empty($err)){
        $token_ganti_password   = md5(rand(0,1000));
        $judul_email            = "Ganti Password";
        $isi_email              = "Seseorang meminta untuk melakukan perubahan password. Silakan klik link di bawah ini:<br/>";
        $isi_email              .= url_dasar()."/ganti_password.php?email=$email&token=$token_ganti_password";
        kirim_email($email,$email,$judul_email,$isi_email);

        $sql1     = "update members set token_ganti_password = '$token_ganti_password' where email = '$email'";
        mysqli_query($koneksi,$sql1);
        $sukses  ="Link ganti password sudah dikirimkan ke email anda.";
    }
}
?>
<?php if($err){ echo "<div class='error'>$err</div>";}?>
<?php if($sukses){ echo "<div class='sukses'>$sukses</div>";}?>
<form action="" method="POST">
    <table>
        <tr>
            <td class="label">Email</td>
            <td><input type="text" name="email" class="input" value="<?php echo $email ?>"/></td>
        </tr>
        <tr>
            <td></td>
            <td>
            <input type="submit" name="submit" value="Lupa Password" class="tbl-biru"/>
            </td>
        </tr>
    </table>
</form>
<?php include("inc_footer.php");?>